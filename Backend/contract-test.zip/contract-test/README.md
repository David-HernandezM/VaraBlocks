## Description

Decentralized Neuronal Network for Vara Network